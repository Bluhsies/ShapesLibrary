var searchData=
[
  ['triangle_0',['Triangle',['../class_triangle.html',1,'Triangle'],['../class_triangle.html#aaefe4ed500c07918d30c6f0e286332c5',1,'Triangle::Triangle()'],['../class_triangle.html#ac6c96bf64bca1238a8ee3e5b6b6e7672',1,'Triangle::Triangle(sf::Vector2f base, float diameter, float height, sf::Color c1)']]]
];
