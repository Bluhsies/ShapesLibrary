var searchData=
[
  ['lab_202_20_2d_20shapes_0',['Lab 2 - Shapes',['../index.html',1,'']]],
  ['lab_20book_201_20starter_20_20code_1',['Lab Book 1 Starter  Code',['../md__c___users__bluh1__one_drive__desktop__university__work__year_2__i_m_a_t2905_lab_code_labbook1assessed__r_e_a_d_m_e.html',1,'']]],
  ['line_2',['Line',['../class_line.html',1,'Line'],['../class_line.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../class_line.html#a101433a4ba70e1b869134f75f4f5bf8a',1,'Line::Line(sf::Vector2f p1, sf::Vector2f p2, sf::Color c1)']]]
];
