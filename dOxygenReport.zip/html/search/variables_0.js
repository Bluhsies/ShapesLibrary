var searchData=
[
  ['customcolours_0',['customColours',['../class_shapes.html#ae53a33d846d39b4f84448a2ef943ad9c',1,'Shapes']]]
];
