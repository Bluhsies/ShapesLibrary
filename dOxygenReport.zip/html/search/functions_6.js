var searchData=
[
  ['octagon_0',['Octagon',['../class_octagon.html#a0bbff93771c467ede6329876a62836a2',1,'Octagon::Octagon()'],['../class_octagon.html#a9be1031d4f7548b674be42f563315099',1,'Octagon::Octagon(sf::Vector2f p1, float p2, sf::Color c1)']]]
];
