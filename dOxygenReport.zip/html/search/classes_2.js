var searchData=
[
  ['dot_0',['Dot',['../class_dot.html',1,'']]]
];
