var searchData=
[
  ['line_0',['Line',['../class_line.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../class_line.html#a101433a4ba70e1b869134f75f4f5bf8a',1,'Line::Line(sf::Vector2f p1, sf::Vector2f p2, sf::Color c1)']]]
];
