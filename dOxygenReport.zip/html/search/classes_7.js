var searchData=
[
  ['triangle_0',['Triangle',['../class_triangle.html',1,'']]]
];
